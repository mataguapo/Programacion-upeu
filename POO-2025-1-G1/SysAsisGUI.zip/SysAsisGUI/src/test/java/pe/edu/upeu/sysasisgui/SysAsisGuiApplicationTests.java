package pe.edu.upeu.sysasisgui;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SysAsisGuiApplicationTests {

	@Test
	void contextLoads() {
	}

}
