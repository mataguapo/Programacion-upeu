package pe.edu.upeu.sysasisgui;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SysAsisGuiApplication {

	public static void main(String[] args) {
		SpringApplication.run(SysAsisGuiApplication.class, args);
	}

}
